package com.svc.inkarne.Graphics;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

import com.svc.inkarne.InkarneAppContext;
import com.svc.inkarne.R;
import com.svc.inkarne.Utility.ConstantsUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;
import java.util.Random;

import javax.microedition.khronos.opengles.GL10;

/**
 * Created by himanshu on 3/11/16.
 */



public class Screenshot {
    public interface ScreenShotListner {
        public void onScreenShotTaken(Bitmap bitmap);
        public void onScreenShotTaken(String imageFilePath);
    }

    private ScreenShotListner listner;
    float x, y,  width,  height;
    GL10 gl;
//    public Screenshot(ScreenShotListner listner) {
//        this.listner = listner;
//    }

    public void SaveToFile(Bitmap bitmap, int size) {
        SaveToFile(bitmap,size,"","DefaultScreenShot");
    }

    public void SaveToFile(Bitmap bitmap, int size, String filePath, String fileName) {
        String TAG = "Saving screenshot image";
        OutputStream outStream = null;
        filePath = Environment.getExternalStorageDirectory().toString() + "/" + filePath;
        File dir = new File( filePath );
        dir.mkdirs();
        File output = new File( filePath, fileName+".png" );
        try {
            outStream = new FileOutputStream(output);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream);
            outStream.flush();
            outStream.close();
            Log.v(TAG, "Saving Screenshot [" + filePath + fileName + "]");
        } catch ( FileNotFoundException e ) {
            Log.e( TAG, "" + e.getMessage() );
        } catch ( IOException e ) {
            Log.e( TAG, "" + e.getMessage() );
        }

    }


    public synchronized Bitmap takeScreenshot(final float x, final float y, final float width, final float height,final GL10 gl, String fileName) {
        String filepath = ConstantsUtil.FILE_PATH_SHARE;
        Bitmap bitmap = takeScreenshot(x,y,width,height,gl,filepath,fileName);
        return bitmap;
    }


    public Bitmap takeScreenshot(float x, float y, float width, float height, GL10 gl,String filePath, String fileName) {
        Bitmap bitmap = takeScreenshot(x,y,width,height,gl);
        SaveToFile(bitmap,(int)(width*height),filePath,fileName);
        //bitmap.recycle();
        return bitmap;
    }

    public Bitmap takeScreenshot(float x, float y, float width, float height, GL10 gl)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.gl =gl;
        return takeScreenshot();
    }

    public Bitmap takeScreenshot()
    {
        int width = (int)this.width;
        int height = (int)this.height;
        int size = width * height;
        ByteBuffer buf = ByteBuffer.allocateDirect(size * 4);
        buf.order(ByteOrder.nativeOrder());
        gl.glReadPixels((int)x, (int)y, width, height, GL10.GL_RGBA, GL10.GL_UNSIGNED_BYTE, buf);
        int data[] = new int[size];
        buf.asIntBuffer().get(data);
        buf = null;
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
        bitmap.setPixels(data, size-width, -width, (int)x, (int)y, width, height);
        data = null;

        short sdata[] = new short[size];
        ShortBuffer sbuf = ShortBuffer.wrap(sdata);
        bitmap.copyPixelsToBuffer(sbuf);
        for (int i = 0; i < size; ++i) {
            //BGR-565 to RGB-565
            short v = sdata[i];
            sdata[i] = (short) (((v&0x1f) << 11) | (v&0x7e0) | ((v&0xf800) >> 11));
        }
        sbuf.rewind();
        bitmap.copyPixelsFromBuffer(sbuf);

        //return bitmap;
        //return bitmapWithText(bitmap);
        return bitmapWithLogo(bitmap);
    }

    public Bitmap bitmapWithLogo(Bitmap bitmap) {
        Bitmap.Config config = bitmap.getConfig();
        if (config == null) {
            config = Bitmap.Config.ARGB_8888;
        }

        Bitmap newBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), config);
        Canvas newCanvas = new Canvas(newBitmap);
        newCanvas.drawBitmap(bitmap, 0, 0, null);
        Bitmap bmLogo = BitmapFactory.decodeResource(InkarneAppContext.getAppContext().getResources(), R.drawable.logo_full_105);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        newCanvas.drawBitmap(bmLogo,15,15,paint);

//        String captionString = ConstantsUtil.TEXT_ON_SHARED_PICS;
//        Paint paintText = new Paint(Paint.ANTI_ALIAS_FLAG);
//        paintText.setColor(Color.BLUE);
//        paintText.setTextSize(50);
//
//        paintText.setStyle(Paint.Style.FILL);
//        paintText.setShadowLayer(10f, 6f, 6f, Color.BLACK);
//
//        Rect rectText = new Rect();
//        paintText.getTextBounds(captionString, 0, captionString.length(), rectText);
//
//        newCanvas.drawText(captionString,
//                bitmap.getWidth() / 2, rectText.height(), paintText);
        return newBitmap;
    }

    public Bitmap bitmapWithText(Bitmap bitmap) {
        Bitmap.Config config = bitmap.getConfig();
        if (config == null) {
            config = Bitmap.Config.ARGB_8888;
        }

        Bitmap newBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), config);
        Canvas newCanvas = new Canvas(newBitmap);

        newCanvas.drawBitmap(bitmap, 0, 0, null);

        String captionString = ConstantsUtil.TEXT_ON_SHARED_PICS;
        Paint paintText = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintText.setColor(Color.BLUE);
        paintText.setTextSize(50);

        paintText.setStyle(Paint.Style.FILL);
        paintText.setShadowLayer(10f, 6f, 6f, Color.BLACK);

        Rect rectText = new Rect();
        paintText.getTextBounds(captionString, 0, captionString.length(), rectText);

        newCanvas.drawText(captionString,
                bitmap.getWidth() / 2, rectText.height(), paintText);
        return newBitmap;
    }

    public synchronized void takeScreenShotAsync(float x, float y, float width, float height, GL10 gl,ScreenShotListner listner) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.gl =gl;
        this.listner = listner;
        new TakeScreenShotTask().execute(this);
    }

    private class TakeScreenShotTask extends AsyncTask<Screenshot, Integer, String> {

        protected String doInBackground(Screenshot... screenshots) {
            Screenshot screenshot = screenshots[0];
            Bitmap bitmap = screenshot.takeScreenshot();

            //screenshot.listner.onScreenShotTaken(bitmap);
            return saveImage(bitmap);
        }

        protected void onProgressUpdate(Integer... progress) {

        }

        protected void onPostExecute(String result) {
            //listner();
            Screenshot.this.listner.onScreenShotTaken(result);
        }
    }

    private String saveImage(Bitmap finalBitmap) {
        String filePath = "";
        String root = Environment.getExternalStorageDirectory().toString();
        File myDir = new File(root + "/inkarne/share");
        myDir.mkdirs();
        Random generator = new Random();
        int n = 10;
        n = generator.nextInt(n);
        String fName = "shareImage-" + n + ".png";
        File file = new File(myDir, fName);
        if (file.exists()) file.delete();
        try {
            FileOutputStream out = new FileOutputStream(file);
            finalBitmap.compress(Bitmap.CompressFormat.PNG, 90, out);
            filePath = file.getAbsolutePath();
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return filePath;
    }
}
