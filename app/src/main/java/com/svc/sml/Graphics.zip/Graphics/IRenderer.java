package com.svc.inkarne.Graphics;

import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLU;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;

import com.svc.inkarne.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import static java.lang.Math.PI;
import static java.lang.Math.cos;
import static java.lang.Math.sin;
import static java.lang.Math.tan;


/**
 * Created by Sarbartha on 14-11-2015.
 */
public abstract class IRenderer implements GLSurfaceView.Renderer {
    private static final float FACECAMYM = 1450f;
    private static final float FACECAMZM = 580f;
    private static final float REDOFACECAMYM = 1450f;
    private static final float REDOFACECAMZM = 480f;
    private static final float SOULDER_CAMYM = 1300f;
    private static final float SOULDER_CAMZM = 1000f;
    private static final float FACECAMYF = 1450f;
    private static final float FACECAMZF = 580f;
    private static final float REDOFACECAMYF = 1500f;
    private static final float REDOFACECAMZF = 450f;
    private static final float SOULDER_CAMYF = 1300f;
    private static final float SOULDER_CAMZF = 1000f;
    private static final float BODYCAMY = 775f;
    private static final float BODYCAMZ = 2300f;

    public static final int LOOKAT_INDEX_FACE = 2;
    public static final int LOOKAT_INDEX_SHOULDER = 1;
    public static final int LOOKAT_INDEX_BODY = 0;

    private static final float INITANGLE = (float) PI;
    private static final String MIMETYPE = "video/avc";
    private CameraMotion camMotion;
    //private VideoEncode vEncode;
    //
    private float px = 0, py = 0, x = 0, y = 0, p2x = 0, p2y = 0;
    protected float scale;
    protected int width, height;
    private boolean isDrag = false, isFace = false;
    private  int lookAtIndex;
    private  int lookAtAngle =0;
    private float camx, camy, camz;
    private final float SCROLL_THRESHOLD = 10;
    private boolean isZoom, faceMode;
    private boolean autoRotation,isBag,isCluch;
    private Vec3d cam, eye;

    private boolean acceptTouch;
    private double oldDist;
    private double newDist;
    private int pointerCount, pointerIndex, pointerId;

    //
    protected final int objNo;
    private Context context;
    private float ambient[][], diffuse[][], position[][], direction[][],specular[][];

    private float mat_diffuse[] = {1.0f, 1.0f, 1.0f, 1.0f};

    private float aspectRatio, rot, arot;

    //obj
    protected Object obj[];
    private boolean isDisp[], isShift;
    protected GL10 gl;
    private boolean firstTouch;
    private long time;
    private float angle, zoom;
    private boolean male;
    private boolean isAutoZoom;
    private int state,script, t;
    private boolean isFrameCapture;
    private int frame,bagC,clutchC;
    private long startTime,endTime;

    public abstract void glInit();

    public abstract void changeState(int no);


    public boolean isAcceptTouch() {
        return acceptTouch;
    }

    public boolean setCamScript(int s,int file) {
        return camMotion.readCamScript(s,file);
    }

    public void setAcceptTouch(boolean acceptTouch) {
        Log.d("IRenderer","touch: "+acceptTouch);

        this.acceptTouch = acceptTouch;
    }

    // IRenderer init
    protected IRenderer(Context context, int objNo, String male) {
      //  this.male=male;
        if(male.equalsIgnoreCase("m"))
            this.male=true;
        else
            this.male=false;
        frame = 0;
        //vEncode=new VideoEncode();
        isFrameCapture = false;
        camMotion = new CameraMotion(context);
        state = 0;
        t = 0;
        script=0;
        isBag=isCluch=false;
        if(this.male)
        {
            setCamScript(0, R.raw.camexternal_male);
            setCamScript(1, R.raw.camapparel_male);
        }
        else {
            setCamScript(0, R.raw.camexternal_female);
            setCamScript(1, R.raw.camapparel_female);
        }
        isAutoZoom = false;
        acceptTouch = true;
        autoRotation = false;
        this.context = context;
        isDisp = new boolean[objNo];
        angle = INITANGLE;
        zoom = 0;
        faceMode = false;
        isShift = false;
        camx = -37.5f;
        camy = 875f;
        camz = 2300f;
        cam = new Vec3d();
        eye = new Vec3d();
        this.objNo = objNo;
        obj = new Object[objNo];
        scale = 1;
        arot = 0;
        for (int i = 0; i < objNo; i++) {
            obj[i] = null;
            isDisp[i] = true;
        }
        ambient = new float[8][];
        diffuse = new float[8][];
        position = new float[8][];
        direction = new float[8][];

        float intensity = (float) 0.7f;
        ambient[0] = new float[]{intensity, intensity, intensity, 1.0f};
        diffuse[0] = new float[]{intensity, intensity, intensity, 1.0f};
        position[0] = new float[]{2000, 1200f, 2000f, 1.0f};
        direction[0] = new float[]{0.0f, 875, 0.0f, 1.0f};

        ambient[1] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        diffuse[1] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        position[1] = new float[]{0, 1200, 2500, 1.0f};
        direction[1] = new float[]{0.0f, 1200, 0.0f, 1.0f};

        ambient[2] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        diffuse[2] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        position[2] = new float[]{2500, 1200, 0, 1.0f};
        direction[2] = new float[]{0.0f, 1200, 0.0f, 1.0f};

        ambient[3] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        diffuse[3] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        position[3] = new float[]{-2500, 1200, -0, 1.0f};
        direction[3] = new float[]{0.0f, 1200, 0.0f, 1.0f};

        ambient[4] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        diffuse[4] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        position[4] = new float[]{0, 1200, -2500, 1.0f};
        direction[4] = new float[]{0.0f, 1200, 0.0f, 1.0f};

        ambient[5] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        diffuse[5] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        position[5] = new float[]{0, 1200, -700, 1.0f};
        direction[5] = new float[]{0.0f, 1200, 0.0f, 1.0f};

        ambient[6] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        diffuse[6] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        position[6] = new float[]{700, 1700, 0, 1.0f};
        direction[6] = new float[]{0.0f, 1400, 0.0f, 1.0f};

        ambient[7] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        diffuse[7] = new float[]{0.2f, 0.2f, 0.2f, 1.0f};
        position[7] = new float[]{-700, 1700, -0, 1.0f};
        direction[7] = new float[]{0.0f, 1400, 0.0f, 1.0f};


        firstTouch = false;
        rot = 0.0f;

    }

    //set a perticular obj visible or not
    public void setIsDisp(int i, boolean b) {
        isDisp[i] = b;
    }

    //set all the objs visible or not
    public void resetDisp(boolean b) {
        for (int i = 0; i < objNo; i++) {
            isDisp[i] = b;
        }
    }

    //Himanshu
    public void changeObj(int no, String objval, Bitmap tex, String side, boolean shine) {
        changeObj(no, objval, tex,shine);
    }

    public void shiftObj(String side) {

    }

    public void setLookat(int lookAtObjn) {
        if (lookAtObjn == 0) {
            viewFace(true);
        } else {
            viewFace(false);
        }
    }

    public void runAutoZoom() {
        isAutoZoom = true;
        state = 0;
        t = 0;
    }
    public void setBag(boolean b)
    {
        isBag=b;
        isCluch=!b;
        Log.d("BAG","Bag: "+isBag+" Clutch:"+isCluch);
    }
    //change one obj
    public synchronized void changeObj(int no, String objval, Bitmap tex, boolean shine) {
        Log.d("IRenderer","Object Loading");
        obj[no] = null;
        obj[no] = new Object(context, objval, gl,shine);
        if (tex != null)
            obj[no].addTexture(tex);
    }

    //not neded now
    public void changeObjFinish() {
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        this.gl = gl;
        GLES20.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
//Setting Lights
        gl.glLightfv(GL10.GL_LIGHT0, GL10.GL_AMBIENT, ambient[0], 0);
        gl.glLightfv(GL10.GL_LIGHT0, GL10.GL_DIFFUSE, diffuse[0], 0);
        gl.glLightfv(GL10.GL_LIGHT0, GL10.GL_POSITION, position[0], 0);
        //       gl.glLightfv(GL10.GL_LIGHT0, GL10.GL_SPOT_DIRECTION, direction[0], 0);

        gl.glLightfv(GL10.GL_LIGHT1, GL10.GL_AMBIENT, ambient[1], 0);
        gl.glLightfv(GL10.GL_LIGHT1, GL10.GL_DIFFUSE, diffuse[1], 0);
        gl.glLightfv(GL10.GL_LIGHT1, GL10.GL_POSITION, position[1], 0);
        gl.glLightfv(GL10.GL_LIGHT1, GL10.GL_SPOT_DIRECTION, direction[1], 0);

        gl.glLightfv(GL10.GL_LIGHT2, GL10.GL_AMBIENT, ambient[2], 0);
        gl.glLightfv(GL10.GL_LIGHT2, GL10.GL_DIFFUSE, diffuse[2], 0);
        gl.glLightfv(GL10.GL_LIGHT2, GL10.GL_POSITION, position[2], 0);
        gl.glLightfv(GL10.GL_LIGHT2, GL10.GL_SPOT_DIRECTION, direction[2], 0);

        gl.glLightfv(GL10.GL_LIGHT3, GL10.GL_AMBIENT, ambient[3], 0);
        gl.glLightfv(GL10.GL_LIGHT3, GL10.GL_DIFFUSE, diffuse[3], 0);
        gl.glLightfv(GL10.GL_LIGHT3, GL10.GL_POSITION, position[3], 0);
        gl.glLightfv(GL10.GL_LIGHT3, GL10.GL_SPOT_DIRECTION, direction[3], 0);

        gl.glLightfv(GL10.GL_LIGHT4, GL10.GL_AMBIENT, ambient[4], 0);
        gl.glLightfv(GL10.GL_LIGHT4, GL10.GL_DIFFUSE, diffuse[4], 0);
        gl.glLightfv(GL10.GL_LIGHT4, GL10.GL_POSITION, position[4], 0);
        gl.glLightfv(GL10.GL_LIGHT4, GL10.GL_SPOT_DIRECTION, direction[4], 0);

        gl.glLightfv(GL10.GL_LIGHT5, GL10.GL_AMBIENT, ambient[5], 0);
        gl.glLightfv(GL10.GL_LIGHT5, GL10.GL_DIFFUSE, diffuse[5], 0);
        gl.glLightfv(GL10.GL_LIGHT5, GL10.GL_POSITION, position[5], 0);
        gl.glLightfv(GL10.GL_LIGHT5, GL10.GL_SPOT_DIRECTION, direction[5], 0);

        gl.glLightfv(GL10.GL_LIGHT6, GL10.GL_AMBIENT, ambient[6], 0);
        gl.glLightfv(GL10.GL_LIGHT6, GL10.GL_DIFFUSE, diffuse[6], 0);
        gl.glLightfv(GL10.GL_LIGHT6, GL10.GL_POSITION, position[6], 0);
        gl.glLightfv(GL10.GL_LIGHT6, GL10.GL_SPOT_DIRECTION, direction[6], 0);

        gl.glLightfv(GL10.GL_LIGHT7, GL10.GL_AMBIENT, ambient[7], 0);
        gl.glLightfv(GL10.GL_LIGHT7, GL10.GL_DIFFUSE, diffuse[7], 0);
        gl.glLightfv(GL10.GL_LIGHT7, GL10.GL_POSITION, position[7], 0);
        gl.glLightfv(GL10.GL_LIGHT7, GL10.GL_SPOT_DIRECTION, direction[7], 0);

//Enabling Lights
        gl.glEnable(GL10.GL_LIGHTING);
        gl.glEnable(GL10.GL_LIGHT0);
        gl.glEnable(GL10.GL_LIGHT1);
        gl.glEnable(GL10.GL_LIGHT2);
        gl.glEnable(GL10.GL_LIGHT3);
        gl.glEnable(GL10.GL_LIGHT4);

        glInit();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        this.width = width;
        this.height = height;
        // Sets the current view port to the new size.
        GLES20.glViewport(0, 0, width, height);
        // Select the projection matrix
        gl.glMatrixMode(GL10.GL_PROJECTION);
        // Reset the projection matrix
        gl.glLoadIdentity();
        // Calculate the aspect ratio of the window
        GLU.gluPerspective(gl, 45.0f,
                (float) width / (float) height,
                300f, 4800.0f);
        aspectRatio = (float) width / (float) height;
        // Select the modelview matrix
        gl.glMatrixMode(GL10.GL_MODELVIEW);
        // Reset the modelview matrix
        gl.glLoadIdentity();
    }

    public void zoomCompleted(){

    }

    public boolean isZoomCompleted(){
         return !isAutoZoom;
    }


    // Draw everything here
    @Override
    public void onDrawFrame(GL10 gl) {
        if (acceptTouch) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
            gl.glEnable(GL10.GL_DEPTH_TEST);
            //    gl.glEnable(GL10.GL_CULL_FACE);
            gl.glLoadIdentity();
            if (isAutoZoom) {
                endTime = System.currentTimeMillis();
                long dt = endTime - startTime;
                startTime = System.currentTimeMillis();
                camMotion.getCamPos(script,state, t, cam, eye);
                GLU.gluLookAt(gl, cam.getX(), cam.getY(), cam.getZ(), eye.getX(), eye.getY(), eye.getZ(), 0f, 1.0f, 0.0f);
                if(t==0 && script==0 && state==0)
                    t++;
                else
                    t+=(int)(dt+55)/55;
               // t++;
                if (t >= camMotion.getStateSteps(script,state)) {
                    state++;
                    t = 0;
                }

                if (state >= camMotion.getMaxStates(script)) {
                    script++;
                    state=0;
                }
                if(script>=camMotion.getMaxScript())
                {
                    isAutoZoom = false;
                    script=0;state=0;
                    zoomCompleted();
                    angle = INITANGLE;
                }

            } else {

                GLU.gluLookAt(gl, (float) ((zoom + camz) * sin(angle)), camy, (float) ((zoom + camz) * cos(angle)), 0, camy, 0, 0f, 1.0f, 0.0f);

            }
            for (int i = 0; i < objNo; i++) {
                if (obj[i] != null && isDisp[i]) {

                    obj[i].draw(gl);

                }
            }
            if (isFrameCapture) {

                int screenshotSize = width * height;
                ByteBuffer bb = ByteBuffer.allocateDirect(screenshotSize * 4);
                bb.order(ByteOrder.nativeOrder());
                gl.glReadPixels(0, 0, width, height, GL10.GL_RGBA, GL10.GL_UNSIGNED_BYTE, bb);
                int pixelsBuffer[] = new int[screenshotSize];
                bb.asIntBuffer().get(pixelsBuffer);
                bb = null;
                Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
                bitmap.setPixels(pixelsBuffer, screenshotSize - width, -width, 0, 0, width, height);
                pixelsBuffer = null;

                short sBuffer[] = new short[screenshotSize];
                ShortBuffer sb = ShortBuffer.wrap(sBuffer);
                bitmap.copyPixelsToBuffer(sb);

                //Making created bitmap (from OpenGL points) compatible with Android bitmap
                for (int i = 0; i < screenshotSize; ++i) {
                    short v = sBuffer[i];
                    sBuffer[i] = (short) (((v & 0x1f) << 11) | (v & 0x7e0) | ((v & 0xf800) >> 11));
                }
                sb.rewind();
                bitmap.copyPixelsFromBuffer(sb);
                saveToInternalStorage(bitmap, frame);
                frame++;
                bitmap.recycle();
            }
        }
    }

    private String saveToInternalStorage(Bitmap bitmapImage, int i) {
        ContextWrapper cw = new ContextWrapper(this.context.getApplicationContext());
        // path to /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath = new File(directory, "img" + i + ".jpg");

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }


    // Change to face mode
    public void viewFace(boolean face) {
        gl.glClearDepthf(1.0f);
        if (face) {
            if(male)
            {
                camy = REDOFACECAMYM;
                camz = REDOFACECAMZM;
            }
            else
            {
                camy = REDOFACECAMYF;
                camz = REDOFACECAMZF;
            }

            isFace = true;
        } else {
            camy = BODYCAMY;
            camz = BODYCAMZ;
            isFace = false;
        }
    }

    public void viewLookAt(int index,int angle) {
       // if(angle != 0)
        this.angle = (float) (angle*3.14/180);
        viewLookAt(index);
    }

    public void viewLookAt(int index) {
        lookAtIndex = index;
        gl.glClearDepthf(1.0f);
        switch (index) {
            case LOOKAT_INDEX_BODY: {
                camy = BODYCAMY;
                camz = BODYCAMZ;
            }
            break;
            case LOOKAT_INDEX_SHOULDER: {
                if(male)
                {
                    camy = SOULDER_CAMYM;
                    camz = SOULDER_CAMZM;
                }
                else
                {
                    camy = SOULDER_CAMYF;
                    camz = SOULDER_CAMZF;
                }
            }
            break;
            case LOOKAT_INDEX_FACE: {
                if(male)
                {
                    camy = FACECAMYM;
                    camz = FACECAMZM;
                }
                else
                {
                    camy = FACECAMYF;
                    camz = FACECAMZF;
                }
            }
            break;
            default:
                break;
        }

    }

    //handles touch function
    public void letsTouch(float x, float y) {
        if (!firstTouch) {
            firstTouch = true;
            time = System.currentTimeMillis();
        } else {
            if (System.currentTimeMillis() - time <= 300)
                onDoubleTap();
            firstTouch = false;
        }
    }

    //for testing perpose only
    public float[] getCurrentModelView(GL10 gl) {
        float[] mModelView = new float[16];
        GLES20.glGetFloatv(GL10.GL_MODELVIEW, mModelView, 0);
        return mModelView;
    }

    public float[] getCurrentProjection(GL10 gl) {
        float[] mProjection = new float[16];
        GLES20.glGetFloatv(GL10.GL_PROJECTION, mProjection, 0);
        return mProjection;
    }

    public void letsDrag(float x, float y, boolean finish) {
        //curScreen=manager.letsDrag(dx,dy,finish,curScreen);
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        int height = metrics.heightPixels;
        float maxHeight = (float) (30 * tan((45 * 0.5) * (PI / 180)));
        float maxWidth = maxHeight * aspectRatio;
        float dragX = 2 * x / (maxHeight);
        angle -= dragX / 500f;
       // Log.d("angle", "" + angle);
    }
    public void setBagClutchNo(int glIndexA10BagsClutches) {
        bagC=glIndexA10BagsClutches;
    }
    public void buttonPressed(int i) {
        //curScreen=manager.buttonPressed(i,curScreen);
    }

    public Bitmap readTexture(final String tex) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Log.d("IRenderer", "texture path: " + tex);
        return BitmapFactory.decodeFile(tex, options);
    }

    public Bitmap readTextureFromAsset(final int tex) {
        Bitmap bm = BitmapFactory.decodeResource(context.getResources(), tex);
        //BitmapFactory.Options options = new BitmapFactory.Options();
        //options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Log.d("IRenderer", "texture path: " + tex);
        return bm;//BitmapFactory.decodeFile(tex,options);
    }

    abstract public void onDoubleTap();

    //reset all objects to null
    public void resetObj() {
        for (int i = 0; i < objNo; i++)
            obj[i] = null;
    }

    //reset ith object to null
    public void resetObj(int i) {
        obj[i] = null;
    }

    //handle touch events. master function.
    public void onTouchEvent(MotionEvent e) {
        if (acceptTouch) {
            DisplayMetrics metrics = context.getResources().getDisplayMetrics();
            int maxWidth = metrics.widthPixels;
            int action = e.getAction();
            switch (action & MotionEvent.ACTION_MASK) {

                case MotionEvent.ACTION_POINTER_DOWN:
                    // movement: cancel the touch press
                    pointerCount = e.getPointerCount();
                    for (int i = 0; i < pointerCount; ++i) {
                        pointerIndex = i;
                        pointerId = e.getPointerId(pointerIndex);
                        if (pointerId == 0) {
                            px = e.getX(0);
                            py = e.getY(0);
                        }
                        if (pointerId == 1) {
                            p2x = e.getX(1);
                            p2y = e.getY(1);
                        }
                    }
                    oldDist = Math.sqrt((px - p2x) * (px - p2x) + (py - p2y) * (py - p2y));
                    isDrag = false;
                    isZoom = true;

                    break;
                case MotionEvent.ACTION_DOWN:
                    px = e.getX();
                    py = e.getY();
                    isDrag = false;
                    break;

                case MotionEvent.ACTION_MOVE:
                    // movement: cancel the touch press
                    isDrag = true;
                    pointerCount = e.getPointerCount();
                    x = e.getX();
                    y = e.getY();
                    if (isZoom) {
                        for (int i = 0; i < pointerCount; ++i) {
                            pointerIndex = i;
                            pointerId = e.getPointerId(pointerIndex);
                            if (pointerId == 0) {
                                px = e.getX(0);
                                py = e.getY(0);
                            }
                            if (pointerId == 1) {
                                p2x = e.getX(1);
                                p2y = e.getY(1);
                            }
                        }
                        newDist = Math.sqrt((px - p2x) * (px - p2x) + (py - p2y) * (py - p2y));
                    } else if (Math.abs(px - e.getX()) > SCROLL_THRESHOLD) {
                        if (px < 9 * maxWidth / 10 && px > maxWidth / 10)
                            letsDrag(x - px, y - py, false);

                    }

                    break;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(px - e.getX()) < SCROLL_THRESHOLD) {
                        letsTouch(e.getX(), e.getY());
                    } else {
                        // Log.d("IRenderer", "points: X:" + px + " maxX:" + maxWidth);
                        if (px > 9 * maxWidth / 10)
                            changeState(1);
                        else if (px < maxWidth / 10)
                            changeState(-1);
                        else
                            letsDrag(x - px, y - py, true);
                    }

                    break;
                case MotionEvent.ACTION_POINTER_UP:
                    isZoom = false;

                    break;
            }
        }

    }
}