package com.svc.inkarne.Graphics;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Vector;

import javax.microedition.khronos.opengles.GL10;

import static java.lang.StrictMath.sqrt;

/**
 * Created by Sarbartha on 16-11-2015.
 */
public class Object {
    private static final String tag = "Object";
    private static final float[] specular={0.8f,0.8f,0.8f,1.0f};
    private Context context;
    private float rotX, rotY, rotZ;
    private float scaleX, scaleY, scaleZ;
    Vector<Vec3d> verts;
    Vector<Vec3d> textures;
    Vector<Vec3d> normals;
    Vector<int[]> vertexColor;
    Vector<face> faces;
    Vector<int[]> facePly;
    public int faceN, vertN;
    private FloatBuffer vertexBuffer,specBuffer;
    private FloatBuffer textureBuffer;
    private FloatBuffer normalBuffer, negNormalBuffer;
    private FloatBuffer colorBuffer;
    private IntBuffer indexBuffer, indexBuffer2, elementbuffer;
    private float maxX;
    private float maxY;
    private boolean shine;

    public float getMaxZ() {
        return maxZ;
    }

    public void setMaxZ(float maxZ) {
        this.maxZ = maxZ;
    }

    public float getMinZ() {
        return minZ;
    }

    public void setMinZ(float minZ) {
        this.minZ = minZ;
    }

    private float maxZ;
    private float minX;
    private float minY;
    private float minZ;
    private int texId;
    private Bitmap mBitmap;
    private boolean mShouldLoadTexture;
    private int mTextureId;
    private float transX, transY;
    private float transZ;

    public Context getContext() {
        return context;
    }

    public Vector<Vec3d> getVerts() {
        return verts;
    }

    public Vector<Vec3d> getTextures() {
        return textures;
    }

    public Vector<Vec3d> getNormals() {
        return normals;
    }

    public Vector<face> getFaces() {
        return faces;
    }

    public int getFaceN() {
        return faceN;
    }

    public int getVertN() {
        return vertN;
    }

    public FloatBuffer getVertexBuffer() {
        return vertexBuffer;
    }

    public FloatBuffer getTextureBuffer() {
        return textureBuffer;
    }

    public FloatBuffer getNormalBuffer() {
        return normalBuffer;
    }

    public IntBuffer getIndexBuffer() {
        return indexBuffer;
    }

    public float getMaxX() {
        return maxX;
    }

    public float getMaxY() {
        return maxY;
    }

    public float getMinX() {
        return minX;
    }

    public float getMinY() {
        return minY;
    }

    private void init(Context context,boolean shine) {
        this.shine=shine;
        this.context = context;
        rotX = 0.0f;
        rotY = 0.0f;
        rotZ = 0.0f;
        scaleX = 1.0f;
        scaleY = 1.0f;
        scaleZ = 1.0f;
        texId = -1;
        faceN = 0;
        vertN = 0;
        mShouldLoadTexture = false;
        mTextureId = -1;
        maxX = -999999;
        maxY = -999999;
        maxZ = -999999;
        minX = 999999;
        minY = 999999;
        minZ = 999999;
        transX = 0.0f;
        transY = 0.0f;
        transZ = 0.0f;
    }

    Object(Context context, String object, GL10 gl,boolean shine) {

        init(context,shine);
        if (object.substring(object.length() - 3).equalsIgnoreCase("obj"))
            readObject(object, gl);
        if (object.substring(object.length() - 3).equalsIgnoreCase("ply"))
            readPLYObject(object, gl);
    }

    public void setTranslation(float x, float y, float z) {
        transX = x;
        transY = y;
        transZ = z;
    }


    void readObjFromAsset(String object, GL10 gl) {
        AssetManager am = context.getAssets();
        int id = 0;
        String data = "";
        int tempI = 0;
        try {
            InputStream in = am.open(object);
            byte[] buffer = new byte[in.available()];
            while (in.read(buffer) != -1) {
                data += new String(buffer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(data.length()>10){
            populateObjVertices(data, gl);
        }
    }

    void readObject(String object, GL10 gl) {

        Log.d("object", "path: " + object);
        File file = new File(object);
        if (file == null || !file.isFile()) {
            readObjFromAsset(object, gl);
            return;
        }
        InputStream in = null;
        String data = "";
        try {
            in = new FileInputStream(file);
            int id = 0;
            int tempI = 0;
            try {
                byte[] buffer = new byte[in.available()];
                while (in.read(buffer) != -1) {
                    data += new String(buffer);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        if (data.length() > 10) {
            populateObjVertices(data, gl);
        }

    }

    void populateObjVertices(String data, GL10 gl) {
        Vec3d center = new Vec3d(0, 0, 0);
        verts = new Vector<Vec3d>();
        textures = new Vector<Vec3d>();
        normals = new Vector<Vec3d>();
        faces = new Vector<face>();
        String lines[] = data.split("\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (line.length() < 2)
                continue;
            if (line.charAt(0) == 'v' && line.charAt(1) == ' ') {

                String[] elems = line.split(" ");
                float X = Float.parseFloat(elems[1]);
                float Y = Float.parseFloat(elems[2]);
                float Z = Float.parseFloat(elems[3]);
                verts.add(new Vec3d(X, Y, Z));
                center.setX((center.getX() * vertN + X) / (vertN + 1));
                center.setY((center.getY() * vertN + Y) / (vertN + 1));
                center.setZ((center.getZ() * vertN + Z) / (vertN + 1));

                vertN++;
                if (Y > maxX)
                    maxX = X;
                if (Y > maxY)
                    maxY = Y;
                if (Z > maxZ)
                    maxZ = Z;

                if (Y < minX)
                    minX = X;
                if (Y < minY)
                    minY = Y;
                if (Z < minZ)
                    minZ = Z;
            }
            if (line.charAt(0) == 'v' && line.charAt(1) == 't') {

                String[] elems = line.split(" ");
                textures.add(new Vec3d(Float.parseFloat(elems[1]), (1.0f - Float.parseFloat(elems[2])), 0.0f));
            }
            if (line.charAt(0) == 'v' && line.charAt(1) == 'n') {
                String[] elems = line.split(" ");
                normals.add(new Vec3d(Float.parseFloat(elems[1]), Float.parseFloat(elems[2]), Float.parseFloat(elems[3])));
            }
//Log.d("obj","I am here");
            if (line.charAt(0) == 'f') {
                String[] elems = line.split(" ");
                String[] v1 = elems[1].split("/");
                String[] v2 = elems[2].split("/");
                String[] v3 = elems[3].split("/");
                //  Log.d("Object",line);
                if (elems.length == 4) {
                    face F = new face();
                    F.addFace(0, Integer.parseInt(v1[0].trim()) - 1, Integer.parseInt(v1[1].trim()) - 1, Integer.parseInt(v1[2].trim()) - 1);
                    F.addFace(1, Integer.parseInt(v2[0].trim()) - 1, Integer.parseInt(v2[1].trim()) - 1, Integer.parseInt(v2[2].trim()) - 1);
                    F.addFace(2, Integer.parseInt(v3[0].trim()) - 1, Integer.parseInt(v3[1].trim()) - 1, Integer.parseInt(v3[2].trim()) - 1);
                    float cx = (verts.get(F.getV()[0]).getX() + verts.get(F.getV()[1]).getX() + verts.get(F.getV()[2]).getX()) / 3;
                    float cy = (verts.get(F.getV()[0]).getY() + verts.get(F.getV()[1]).getY() + verts.get(F.getV()[2]).getY()) / 3;
                    float cz = (verts.get(F.getV()[0]).getZ() + verts.get(F.getV()[1]).getZ() + verts.get(F.getV()[2]).getZ()) / 3;
                    faces.add(F);
                    faceN++;
                }
            }
        }

        float[] vertCoord = new float[faceN * 3 * 3];
        float[] texCoord = new float[faceN * 3 * 2];
        float[] normCoord = new float[faceN * 3 * 3];
        int[] indexCoord = new int[faceN * 3 * 3];
        int[] indexCoord2 = new int[faceN * 3 * 3];


        for (int i = 0; i < faceN; i++) {
            for (int j = 0; j < 3; j++) {
                vertCoord[(i * 9 + j * 3)] = verts.get(faces.get(i).getV()[j]).getX();
                vertCoord[(i * 9 + j * 3 + 1)] = verts.get(faces.get(i).getV()[j]).getY();
                vertCoord[(i * 9 + j * 3 + 2)] = verts.get(faces.get(i).getV()[j]).getZ();

                normCoord[(i * 9 + j * 3)] = normals.get(faces.get(i).getN()[j]).getX();
                normCoord[(i * 9 + j * 3 + 1)] = normals.get(faces.get(i).getN()[j]).getY();
                normCoord[(i * 9 + j * 3 + 2)] = normals.get(faces.get(i).getN()[j]).getZ();

                texCoord[(i * 6 + j * 2)] = textures.get(faces.get(i).getT()[j]).getX();
                texCoord[(i * 6 + j * 2 + 1)] = textures.get(faces.get(i).getT()[j]).getY();

                indexCoord[(i * 3 + j)] = ((i) * 3 + (j));

            }

        }
        //     Log.d("Object", "Indexcoord: " + indexCoord.length);
        ByteBuffer vbb = ByteBuffer.allocateDirect(vertCoord.length * 4);
        vbb.order(ByteOrder.nativeOrder());
        vertexBuffer = vbb.asFloatBuffer();
        vertexBuffer.put(vertCoord);
        vertexBuffer.position(0);
        ByteBuffer nbb = ByteBuffer.allocateDirect(normCoord.length * 4);
        nbb.order(ByteOrder.nativeOrder());
        normalBuffer = nbb.asFloatBuffer();

        normalBuffer.put(normCoord);
        normalBuffer.position(0);
        ByteBuffer ibb = ByteBuffer.allocateDirect(indexCoord.length * 4);
        ibb.order(ByteOrder.nativeOrder());
        indexBuffer = ibb.asIntBuffer();
        indexBuffer.put(indexCoord);
        indexBuffer.position(0);

        ByteBuffer bb = ByteBuffer.allocateDirect(specular.length * 4);
        bb.order(ByteOrder.nativeOrder());
        specBuffer = bb.asFloatBuffer();
        specBuffer.put(specular);
        specBuffer.position(0);
//        GL10.glGenBuffers(1,indexBuffer);
//        GL10.glBindBuffer(GL10.GL_ELEMENT_ARRAY_BUFFER,0);
//        GL10.glBufferData(GL10.GL_ELEMENT_ARRAY_BUFFER, indexCoord.length * 4, indexBuffer, GL10.GL_STATIC_DRAW);

//        ibb = ByteBuffer.allocateDirect(indexCoord2.length * 4);
//        ibb.order(ByteOrder.nativeOrder());
//        indexBuffer2 = ibb.asIntBuffer();
//        indexBuffer2.put(indexCoord2);
//        indexBuffer2.position(0);

        setTextureCoordinates(texCoord);

    }


    private int getOBJPosition(float dist, int start, int end) {
        if (end <= start)
            return start;
        int mid = (end + start) / 2;
        if (dist < faces.get(mid).getDist()) {
            start = mid + 1;
            return getOBJPosition(dist, start, end);
        } else {
            end = mid - 1;
            return getOBJPosition(dist, start, end);
        }
    }

    void readPlyFromAsset(String object, GL10 gl) {
        AssetManager am = context.getAssets();
        int id = 0;
        String data = "";
        int tempI = 0;
        try {
            InputStream in = am.open(object);
            byte[] buffer = new byte[in.available()];
            while (in.read(buffer) != -1) {
                data += new String(buffer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(data.length()>10){
            populatePlyVertices(data, gl);
        }
    }

    void readPLYObject(String object, GL10 gl) {
        //    Log.d("object","path: "+object);
        File file = new File(object);
        Log.d("object", "path: " + object);
        if (file == null || !file.isFile()) {
            readPlyFromAsset(object, gl);
            return;
        }
        InputStream in = null;
        String data = "";
        try {
            in = new FileInputStream(file);
            int id = 0;
            int tempI = 0;
            try {
                byte[] buffer = new byte[in.available()];
                while (in.read(buffer) != -1) {
                    data += new String(buffer);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if(data.length()>100){
            populatePlyVertices(data,gl);
        }
    }

    void populatePlyVertices(String data,GL10 gl) {
        //    Log.d("object","path: "+object);
            verts = new Vector<Vec3d>();
            textures = new Vector<Vec3d>();
            normals = new Vector<Vec3d>();
            facePly = new Vector<int[]>();
            String lines[] = data.split("\r\n");
            if (lines.length < 10) {
                lines = data.split("\n");
            }
            boolean header = true;
            int vertLoop = 0, faceLoop = 0, property = 0, px = 0, py = 0, pz = 0, pnx = 0, pny = 0, pnz = 0, ps = 0, pt = 0;
            //  Log.d("line",""+lines.length);

            for (int i = 0; i < lines.length; i++) {
                String[] elems = lines[i].split(" ");

                if (header) {
                    if (elems[0].equalsIgnoreCase("element")) {
                        //   Log.d("elems",elems[2]);
                        if (elems[1].equalsIgnoreCase("vertex"))
                            vertLoop = Integer.parseInt(elems[2].trim());
                        else
                            faceLoop = Integer.parseInt(elems[2].trim());
                    }
                    if (elems[0].equalsIgnoreCase("property")) {
                        if (elems[2].equalsIgnoreCase("x"))
                            px = property;
                        if (elems[2].equalsIgnoreCase("y"))
                            py = property;
                        if (elems[2].equalsIgnoreCase("z"))
                            pz = property;

                        if (elems[2].equalsIgnoreCase("nx"))
                            pnx = property;
                        if (elems[2].equalsIgnoreCase("ny"))
                            pny = property;
                        if (elems[2].equalsIgnoreCase("nz"))
                            pnz = property;

                        if (elems[2].equalsIgnoreCase("s"))
                            ps = property;
                        if (elems[2].equalsIgnoreCase("t"))
                            pt = property;


                        property++;
                    }
                    if (elems[0].equalsIgnoreCase("end_header")) {
                        header = false;
                    }
                } else {
                    //   Log.d("vertLoop",""+vertLoop);
                    // Log.d("verts",""+elems.length);
                    if (elems.length == 8) {
                        float X = Float.parseFloat(elems[px].trim());
                        float Y = Float.parseFloat(elems[py].trim());
                        float Z = Float.parseFloat(elems[pz].trim());
                        verts.add(new Vec3d(X, Y, Z));   // changing axis only for display
                        vertN++;
                        if (Y > maxX)
                            maxX = X;
                        if (Y > maxZ)
                            maxZ = Y;
                        if (Z > maxY)
                            maxY = Z;

                        if (Y < minX)
                            minX = X;
                        if (Y < minZ)
                            minZ = Y;
                        if (Z < minY)
                            minY = Z;

                        float nx = Float.parseFloat(elems[pnx].trim());
                        float ny = Float.parseFloat(elems[pny].trim());
                        float nz = Float.parseFloat(elems[pnz].trim());
                        normals.add(new Vec3d(nx, ny, nz));//normal changed for display
                        float s = Float.parseFloat(elems[ps]);
                        float t = 1.0f - Float.parseFloat(elems[pt]);
                        textures.add(new Vec3d(s, t, 0));
                    }
                    //   Log.d("ply",lines[i]+" "+i);
                    //   Log.d("plyelems",elems[0]+" "+elems.length);
                    if (elems.length == 4) {
                        int f[] = new int[3];
                        f[0] = Integer.parseInt(elems[1]);
                        f[1] = Integer.parseInt(elems[2]);
                        f[2] = Integer.parseInt(elems[3]);
                        facePly.add(f);
                        faceN++;
                        faceLoop--;
                        if (faceLoop <= 0)
                            break;
                    }

                }
            }
            //  Log.d("PLY",""+vertN+" "+faceN);
            // Log.d("PLY",""+px+"  "+py+"  "+pz+"  "+pnx+"  "+pny+"  "+pnz+"  "+ps+"  "+pt);

        float[] vertCoord = new float[vertN * 3];
        float[] texCoord = new float[vertN * 2];

        float[] normCoord = new float[vertN * 3];
        float[] normCoord2 = new float[vertN * 3];

        int[] indexCoord = new int[faceN * 3 * 3];
        for (int i = 0; i < vertN; i++) {
            vertCoord[(i * 3)] = verts.get(i).getX();
            vertCoord[(i * 3 + 1)] = verts.get(i).getY();
            vertCoord[(i * 3 + 2)] = verts.get(i).getZ();
            float val = (float) sqrt(normals.get(i).getX() * normals.get(i).getX() + normals.get(i).getY() * normals.get(i).getY() + normals.get(i).getZ() * normals.get(i).getZ());
            normCoord[(i * 3)] = normals.get(i).getX() / val;
            normCoord[(i * 3 + 1)] = normals.get(i).getY() / val;
            normCoord[(i * 3 + 2)] = normals.get(i).getZ() / val;

            normCoord2[(i * 3)] = -normals.get(i).getX() / val;
            normCoord2[(i * 3 + 1)] = -normals.get(i).getY() / val;
            normCoord2[(i * 3 + 2)] = -normals.get(i).getZ() / val;

            texCoord[(i * 2)] = textures.get(i).getX();
            texCoord[(i * 2 + 1)] = textures.get(i).getY();


        }
        for (int i = 0; i < faceN; i++) {
            for (int j = 0; j < 3; j++) {
                indexCoord[(i * 3 + j)] = facePly.get(i)[j];
            }
        }
        ByteBuffer vbb = ByteBuffer.allocateDirect(vertCoord.length * 4);
        vbb.order(ByteOrder.nativeOrder());
        vertexBuffer = vbb.asFloatBuffer();
        vertexBuffer.put(vertCoord);
        vertexBuffer.position(0);
        ByteBuffer nbb = ByteBuffer.allocateDirect(normCoord.length * 4);
        nbb.order(ByteOrder.nativeOrder());
        normalBuffer = nbb.asFloatBuffer();
        normalBuffer.put(normCoord);
        normalBuffer.position(0);

        nbb = ByteBuffer.allocateDirect(normCoord2.length * 4);
        nbb.order(ByteOrder.nativeOrder());
        negNormalBuffer = nbb.asFloatBuffer();
        negNormalBuffer.put(normCoord);
        negNormalBuffer.position(0);

        ByteBuffer ibb = ByteBuffer.allocateDirect(indexCoord.length * 4);
        ibb.order(ByteOrder.nativeOrder());
        indexBuffer = ibb.asIntBuffer();
        indexBuffer.put(indexCoord);
        indexBuffer.position(0);

        ByteBuffer vcb = ByteBuffer.allocateDirect(texCoord.length * 4);
        vcb.order(ByteOrder.nativeOrder());
        textureBuffer = vcb.asFloatBuffer();
        textureBuffer.put(texCoord);
        textureBuffer.position(0);
        ByteBuffer bb = ByteBuffer.allocateDirect(specular.length * 4);
        bb.order(ByteOrder.nativeOrder());
        specBuffer = bb.asFloatBuffer();
        specBuffer.put(specular);
        specBuffer.position(0);
        Log.d("Object", "indexbuffer size: " + indexBuffer.limit());
        //setTextureCoordinates(texCoord);

    }

    public void addTexture(Bitmap tex) {
        // loadBitmap(BitmapFactory.decodeResource(this.context.getResources(), texId));
        loadBitmap(tex);
    }

    protected void setTextureCoordinates(float[] textureCoords) {
        ByteBuffer byteBuf = ByteBuffer.allocateDirect(textureCoords.length * 4);
        byteBuf.order(ByteOrder.nativeOrder());
        textureBuffer = byteBuf.asFloatBuffer();
        textureBuffer.put(textureCoords);
        textureBuffer.position(0);
    }

    public float getTransX() {
        return transX;
    }

    public float getTransY() {
        return transY;
    }

    public void draw(GL10 gl) {
        gl.glEnable(GL10.GL_NORMALIZE);
        gl.glAlphaFunc(GL10.GL_GREATER, 0f);
        gl.glEnable(GL10.GL_ALPHA_TEST);
        if (mShouldLoadTexture) {
            loadGLTexture(gl);
            mShouldLoadTexture = false;
        }
        if (mTextureId != -1 && textureBuffer != null) {
            gl.glEnable(GL10.GL_TEXTURE_2D);
            // Enable the texture state
            gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
            gl.glBlendFunc(GL10.GL_SRC_ALPHA, GL10.GL_ONE_MINUS_SRC_ALPHA);
            gl.glEnable(GL10.GL_BLEND);
            // Point to our buffers
            gl.glTexCoordPointer(2, GL10.GL_FLOAT, 0, textureBuffer);
            gl.glBindTexture(GL10.GL_TEXTURE_2D, mTextureId);
        }
        if(shine)
        {
            //gl.glMaterialfv(GL10.GL_FRONT_AND_BACK,GL10.GL_SPECULAR,specBuffer);
        }
        //  GL10.glDepthMask(true);
        gl.glPushMatrix();
        gl.glScalef(scaleX, scaleY, scaleZ);
        gl.glPushMatrix();
        gl.glTranslatef(transX, transY, transZ);

        gl.glPushMatrix();
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);
        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
        gl.glNormalPointer(GL10.GL_FLOAT, 0, normalBuffer);
        gl.glEnableClientState(GL10.GL_NORMAL_ARRAY);


        gl.glEnable(GL10.GL_NORMALIZE);
        gl.glFrontFace(GL10.GL_CCW);
        gl.glDrawElements(GL10.GL_TRIANGLES, indexBuffer.limit(), GLES20.GL_UNSIGNED_INT, indexBuffer);
        gl.glDisableClientState(GL10.GL_NORMAL_ARRAY);


        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
        gl.glPopMatrix();
        gl.glPopMatrix();
        gl.glPopMatrix();

        if (mTextureId != -1 && textureBuffer != null) {
            gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
            gl.glDisable(GL10.GL_BLEND);
        }

    }

    public float getRotY() {
        return rotY;
    }

    public void rotate(float x, float y, float z) {
        rotX = x;
        rotY = y;
        rotZ = z;
    }

    public void scale(float x, float y, float z) {
        scaleX = x;
        scaleY = y;
        scaleZ = z;

        if (scaleX < 0.5f) scaleX = 0.5f;
        if (scaleX > 2.5f) scaleX = 2.5f;
        if (scaleY < 0.5f) scaleY = 0.5f;
        if (scaleY > 2.5f) scaleY = 2.5f;
        if (scaleZ < 0.5f) scaleZ = 0.5f;
        if (scaleZ > 2.5f) scaleZ = 2.5f;
    }

    public void loadBitmap(Bitmap bitmap) { // New function.
        this.mBitmap = bitmap;
        mShouldLoadTexture = true;
    }

    private void loadGLTexture(GL10 gl) { // New function
        // Generate one texture pointer...
        int[] textures = new int[1];
        gl.glGenTextures(1, textures, 0);
        mTextureId = textures[0];

        // ...and bind it to our array
        gl.glBindTexture(GL10.GL_TEXTURE_2D, mTextureId);
        // GLES20.glGenerateMipmap(GL10.GL_TEXTURE_2D);
        // Create Nearest Filtered Texture
        gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER, GL10.GL_NEAREST);
        gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER, GL10.GL_NEAREST);

        //Different possible texture parameters, e.g. GL10.GL_CLAMP_TO_EDGE
        gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_WRAP_S, GL10.GL_REPEAT);
        gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_WRAP_T, GL10.GL_REPEAT);

        // Use the Android GLUtils to specify a two-dimensional texture image
        // from our bitmap
        GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, mBitmap, 0);
    }

    public void resizeTex(int texture, int w, int h) {
        float[] texCoord = new float[faceN * 3 * 2];
        for (int i = 0; i < faceN; i++) {
            for (int j = 0; j < 3; j++) {
                texCoord[i * 6 + j * 2] = ((textures.get(faces.get(i).getT()[j]).getX()) / w) + ((1.0f / w) * (texture % w));
                texCoord[i * 6 + j * 2 + 1] = ((textures.get(faces.get(i).getT()[j]).getY()) / h) + ((1.0f / h) * (texture / w));
            }

        }
        setTextureCoordinates(texCoord);
    }

}
